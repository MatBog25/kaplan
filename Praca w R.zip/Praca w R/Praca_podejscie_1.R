dane <- read.csv("clinical.tsv", sep = "\t")
data <- na.omit(dane)
data <- data[!duplicated(data$case_id), ]


library(survival)
library(survminer)


#cox <- coxph(Surv(days_to_death, cens) ~ race + age_at_index + tumor_size + node_caps, data = dane)

for(i in 1:nrow(data)){
  if(data[i,10] == '\'--'){
    data[i,10] = 0
  }
}

#as.numeric(data$days_to_death)

for(i in 1:nrow(data)){
  if(data[i,16] == 'dead'){
    data[i,16] = 0
  }
  else{
    data[i,16] = 1
  }
}
data2 = data


mayer = survfit(Surv(as.numeric(days_to_death), as.numeric(vital_status))~ajcc_pathologic_stage, data = data2)
summary(mayer)


plot(mayer, xlab = 'Czas', ylab = 'Prawdopodobienstwo smierci')
ggsurvplot(mayer, xlab = 'Czas', ylab = 'Prawdopodobienstwo przezycia', color = 'ajcc_pathologic_stage')


